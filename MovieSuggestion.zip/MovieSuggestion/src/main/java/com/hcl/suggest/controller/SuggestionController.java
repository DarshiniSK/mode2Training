package com.hcl.suggest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcl.suggest.dto.TransactionDTO;
import com.hcl.suggest.service.SuggestMovie;


@Controller
public class SuggestionController {
	
	@Autowired SuggestMovie suggestmovie;
	  @RequestMapping(value="suggest/movie", method=RequestMethod.GET)
	    @ResponseBody public  List<TransactionDTO> getSuggestion() {
		  
			return suggestmovie.getAllCustomers();
	    }

	
	
}
