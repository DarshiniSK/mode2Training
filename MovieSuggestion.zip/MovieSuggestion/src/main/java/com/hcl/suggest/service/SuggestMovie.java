package com.hcl.suggest.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.suggest.dto.TransactionDTO;

@Service
public class SuggestMovie {

	public List<TransactionDTO> getAllCustomers() {
		// TODO Auto-generated method stub
		RestTemplate restTemplate=new RestTemplate();
		List<TransactionDTO> transactiondtolist=restTemplate.getForObject("http://localhost:8080/transaction/pagination", List.class);
		return transactiondtolist;
	}

	
	
}
