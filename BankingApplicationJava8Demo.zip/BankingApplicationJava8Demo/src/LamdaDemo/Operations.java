package LamdaDemo;

import java.util.ArrayList;
import java.util.List;

public class Operations {
	String message;
	List<String> msglist=new ArrayList<>();

	public List<String> withdraw(int withdrawAmt,String accno,List<Customer> custList4){
		System.out.println("Transaction: withdraw");
	for(int i=0;i<custList4.size();i++){
		if(accno.equals(custList4.get(i).accno)){
			custList4.get(i).balance-=withdrawAmt;
			System.out.println(custList4.get(i).name+"\t"+custList4.get(i).age+"\t"+custList4.get(i).phoneno+"\t"+custList4.get(i).accno+"\t"+custList4.get(i).balance);
            message="Amount of"+withdrawAmt+"rs. is withdrawn from the account number"+custList4.get(i).accno;
            msglist.add(message);
		}
		
	}
	return msglist;
	
	}
	

	public List<String> deposit(int depositAmt, String accno, List<Customer> custList4) {
		// TODO Auto-generated method stub
		System.out.println("Transaction: deposit");
		for(int i=0;i<custList4.size();i++){
			if(accno.equals(custList4.get(i).accno)){
				custList4.get(i).balance+=depositAmt;
				System.out.println(custList4.get(i).name+"\t"+custList4.get(i).age+"\t"+custList4.get(i).phoneno+"\t"+custList4.get(i).accno+"\t"+custList4.get(i).balance);
	            message="Amount of"+depositAmt+"rs. is deposited to account number"+custList4.get(i).accno;
		            msglist.add(message);
				
			}
	}
		return msglist;

}
}
