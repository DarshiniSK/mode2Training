package LamdaDemo;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.ElementType;

@Retention(RetentionPolicy.RUNTIME)  
@Target(ElementType.TYPE)  
@interface Display1 {
	int age();
	String name();

}


@Display1(name ="darshini",age=21)
public  class TestCustomAnnotation1 {

		public static void main(String args[])   {
			Display1 d=TestCustomAnnotation1.class.getAnnotation(Display1.class);
	        System.out.println(d.name()+"\t"+d.age());
		}
}
