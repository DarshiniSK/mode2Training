package LamdaDemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class NumDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
List<Integer> list=Arrays.asList(11111,22222,33333,44444);
/*System.out.println("enter the accnumber");

for(int i=0;i<4;i++){
	int num=sc.nextInt();
	list.add(num);
	
}*//*
StringBuilder sb = list.stream()
.mapToInt(l -> l.charAt(0))
.collect(StringBuilder::new, 
         StringBuilder::appendCodePoint, 
         StringBuilder::append);*/

List<String> list1=list.stream().map(i -> "SBI"+i).collect(Collectors.toList());


List<String> list2=list1.stream().filter(i -> i.length()==8).limit(5).collect(Collectors.toList());


List<Customer> custList=Arrays.asList(new Customer("Darshu",21,"9267839234",10000),
		new Customer("Smita",17,"82839234",20000),
		new Customer("Likith",20,"6783945234",30000),
		new Customer("Tejas",23,"8345679234",40000));

List<Customer> custList1=custList.stream().filter(i->((i.phoneno).length()==10)).collect(Collectors.toList());
List<Customer> custList2=custList1.stream().filter(i->((i.age)>18)).collect(Collectors.toList());
List<Customer> custList3=custList2.stream().filter(i->Character.isUpperCase(i.name.charAt(0))).collect(Collectors.toList());
List<Customer> custList4=custList3.stream().sorted().collect(Collectors.toList());

for(int i=0;i<custList4.size();i++){
	
	custList4.get(i).accno=list2.get(i);
}
System.out.println("Customer Details");
System.out.println("Name\tAge\tPhone Number\tAccount no\tbalance");
for(int i=0;i<custList4.size();i++)
	System.out.println(custList4.get(i).name+"\t"+custList4.get(i).age+"\t"+custList4.get(i).phoneno+"\t"+custList4.get(i).accno+"\t"+custList4.get(i).balance);

int withdrawAmt = 0;
int depositAmt=0;
int ch,count = 0;
String accno = null;
Operations op=new Operations();
List<String> msg=new ArrayList<>();

while(count==0){
System.out.println("enter the choice 1:withdraw 2:deposit 3:last transactions\n");
ch=sc.nextInt();
switch(ch){
case 1:
	System.out.println("enter amount to withdraw\n");
	 withdrawAmt=sc.nextInt();
	 sc.nextLine();
	 System.out.println("enter acc no\n");
	accno=sc.nextLine();
	msg=op.withdraw(withdrawAmt,accno,custList4);
	break;
	
case 2: System.out.println("enter amount to deposit\n");
depositAmt=sc.nextInt();
sc.nextLine();
System.out.println("enter acc no\n");
accno=sc.nextLine();
msg=op.deposit(depositAmt,accno,custList4);
break;

case 3: System.out.println("last transaction\n");
        for(int i=0;i<msg.size();i++){
        	System.out.println(msg.get(i));
        }
        break;
default:System.out.println("invalid choice\n");
	   break;

}
System.out.println("do you want to continue the transaction  0:yes 1:no\n");
count=sc.nextInt();
}
}
}
