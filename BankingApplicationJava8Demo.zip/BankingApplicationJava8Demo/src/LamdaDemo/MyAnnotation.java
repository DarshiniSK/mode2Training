package LamdaDemo;

import java.lang.annotation.Repeatable;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;

@Repeatable(Customers.class)
@interface Customer1{
	int age();  
	String name();  

}
@Retention(RetentionPolicy.RUNTIME)
@interface Customers{
Customer1[] value();
}

@Customer1(age=20,name="darshini gowda") 
@Customer1(age=16,name="likhith gowda") 

public class MyAnnotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer1[] cust=MyAnnotation.class.getAnnotationsByType(Customer1.class);
		for(Customer1 customer:cust){
		System.out.println(customer.name());
		System.out.println(customer.age());
		}
	}

}
