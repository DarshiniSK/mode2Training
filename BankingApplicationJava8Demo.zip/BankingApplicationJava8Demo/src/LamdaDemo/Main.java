package LamdaDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// using lamda
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(20);
		list.add(3);
		list.add(40);

		List<String> list1 = new ArrayList<String>();
		list1.add(" ");
		list1.add("darshini");
		list1.add("likhith");
		list1.add(" ");

		list.stream().filter(p -> p % 2 == 0).forEach(System.out::println);

		list1.stream().filter(n -> !n.equals("")).forEach(System.out::println);

		// without using lamda
		Iterator<Integer> itr = list.iterator();
		while (itr.hasNext()) {
			int number = itr.next();
			if (number % 2 == 0) {
				System.out.println(number);
			}
		}

		Iterator<String> itr1 = list1.iterator();
		while (itr1.hasNext()) {
			String number = itr1.next();
			if (!number.equals("")) {
				System.out.println(number);

			}
		}
	}
}