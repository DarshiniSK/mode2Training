package LamdaDemo;

public class Customer implements Comparable<Customer> {

	String name;
	int age;
	String phoneno;
	String accno;
	int balance;

	public Customer(String accno) {
		super();
		this.accno = accno;
	}

	public Customer(String name, int age, String phoneno, int balance) {
		super();
		this.name = name;
		this.age = age;
		this.phoneno = phoneno;
		this.balance = balance;
	}

	@Override
	public int compareTo(Customer ob) {
		// TODO Auto-generated method stub
		return name.compareTo(ob.getName());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
