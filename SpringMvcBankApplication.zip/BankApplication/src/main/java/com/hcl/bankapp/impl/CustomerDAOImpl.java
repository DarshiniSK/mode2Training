package com.hcl.bankapp.impl;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.bankapp.CustomerController;
import com.hcl.bankapp.dao.CustomerDAO;
import com.hcl.bankapp.model.Customer;

public class CustomerDAOImpl implements CustomerDAO {

	  @Autowired DataSource dataSource;
	  
	  @Autowired JdbcTemplate jdbcTemplate;
	
	  
	  private static final Logger logger = LoggerFactory.getLogger(CustomerDAOImpl.class);
	  
	  //registering the customer with a bank account
	  
	@Override
	public void register(Customer cust) {
		// TODO Auto-generated method stub
		
		List<String> acclist= new ArrayList<String>();
		int accdig;
		for(int i=0;i<9;i++)
		{
			accdig= (int) (Math.random()* Math.pow(10, 7));
			String accNum="SBI"+accdig;
			logger.info("Account number is="+accNum);
			
			acclist.add(accNum);
		}
		
		logger.info("Entering database...");
		String sql="insert into customer_det"+
				"(cust_name,cust_age,cust_phno,cust_mail,cust_job) values(?,?,?,?,?)";
	
	jdbcTemplate.update(sql,new Object[] {cust.getName(),cust.getAge(),cust.getPhno(),cust.getMail(),cust.getJob()});
	
	if(cust.getAge()>18)
	{
		logger.info("Updating accno to the account holder...");
		String sql1="update customer_det set cust_accno=? where cust_name=?";
		jdbcTemplate.update(sql1,acclist.get(0),cust.getName());
	}
	
	
	}
	
	
	
	
	
	
	
	@Override
	public void addAcc(Customer cust) {
		// TODO Auto-generated method stub
		logger.info("Displaying list data...");
		List<Customer> custlist= new ArrayList<Customer>();
		custlist.add(cust);
		for(int i=0;i<custlist.size();i++)
		{
			System.out.println(custlist.get(i).getName());
		}
		
		
		
	}

}
