package com.hcl.bankapp.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcl.bankapp.dao.CustomerDAO;
import com.hcl.bankapp.dao.CustomerService;
import com.hcl.bankapp.model.Customer;


public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDAO custDao;
	
	
	//cust object contains customer data 
	
	@Override
	public void register(Customer cust) {
		// TODO Auto-generated method stub
		custDao.register(cust);
	}

	
	//adding customer account details
	@Override
	public void addAccount(Customer cust) {
		// TODO Auto-generated method stub
		custDao.addAcc(cust);
	}

}
