package com.hcl.bankapp.dao;

import com.hcl.bankapp.model.Customer;


public interface CustomerDAO {

	
	public void register(Customer cust);

	public void addAcc(Customer cust);
}
