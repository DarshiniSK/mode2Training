package com.hcl.bankapp;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.bankapp.dao.CustomerService;
import com.hcl.bankapp.model.Customer;



@Controller
public class CustomerController {

	
	
	  @Autowired CustomerService customerService;
	 
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	private Map<String, Customer> cust = null;

	public CustomerController() {
		cust = new HashMap<String, Customer>();
	}

	
	//customer registration
	
	@RequestMapping(value = "/cust/add", method = RequestMethod.GET)
	public String saveUserPage(Model model) {
		logger.info("Returning userregn.jsp page");
		model.addAttribute("cust", new Customer());
		return "custregn";
	}

	@RequestMapping(value = "/cust/add.do", method = RequestMethod.POST)
	public String saveUserAction(@Valid Customer cust, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning userregn.jsp page");
			return "custregn";
		}
		logger.info("Returning success-register.jsp page");
		model.addAttribute("cust", cust);
		
		customerService.register(cust);
		customerService.addAccount(cust);

		return "Success-registered";
	}
	
}
