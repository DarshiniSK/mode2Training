package com.cal.webservice;

import java.rmi.RemoteException;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			CalculatorStub stub = new CalculatorStub();
			CalculatorStub.Addition param = new CalculatorStub.Addition();
			CalculatorStub.Subtraction param1=new CalculatorStub.Subtraction();
			CalculatorStub.Multiplication param2=new CalculatorStub.Multiplication();
			CalculatorStub.Division param3=new CalculatorStub.Division();
			
			param.setA(80);
			param.setB(50);
			
			param1.setA(80);
			param1.setB(50);
			
			param2.setA(10);
			param2.setB(50);
			
			param3.setA(50);
			param3.setB(10);
			
			
			CalculatorStub.AdditionResponse response = stub.addition(param);
			int result = response.get_return();
			System.out.println("Addition of 80 and 50  is =" + result);
			
			CalculatorStub.SubtractionResponse response1=stub.subtraction(param1);
			int result1=response1.get_return();
			System.out.println("subtraction of 80 and 50  is  =" + result1);

			CalculatorStub.MultiplicationResponse response2=stub.multiplication(param2);
			int result2=response2.get_return();
			System.out.println("multiplication of 10 and 50  is  =" + result2);

			CalculatorStub.DivisionResponse response3=stub.division(param3);
			int result3=response3.get_return();
			System.out.println("division of 50 and 10  is  =" + result3);

			
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

}
