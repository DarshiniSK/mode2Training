package com.hcl.pp.springbootdemo.dao;




import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.pp.springbootdemo.model.Customer;



@Repository
public interface CustomerDAO extends CrudRepository<Customer,Integer>{

	
    

		
	
}
