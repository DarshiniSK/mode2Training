package com.hcl.pp.springbootdemo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.pp.springbootdemo.model.Beneficiary;
import com.hcl.pp.springbootdemo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService beneficiaryService;

	@RequestMapping(value = "/transaction/addbeneficiary")
	public String addBeneficiaries(@RequestBody Beneficiary beneficiary) {
		return beneficiaryService.addBeneficiaries(beneficiary);

	}

	@RequestMapping(value = "/transaction/getbendetails/{ifsccode}", method = RequestMethod.GET)
	public Optional<Beneficiary> findByIfsccode(@PathVariable(value = "ifsccode") String ifsccode) {
		return beneficiaryService.findByIfsccode(ifsccode);
	}

	@RequestMapping(value = "/transaction/getbendetails/{ifsccode}/{beneaccno}", method = RequestMethod.GET)
	public Optional<Beneficiary> findByIfsccodeAndBeneaccno(@PathVariable(value = "ifsccode") String ifsccode,@PathVariable(value = "beneaccno") String beneaccno) {
		return beneficiaryService.findByIfsccodeAndBeneaccno(ifsccode, beneaccno);
	}

}
