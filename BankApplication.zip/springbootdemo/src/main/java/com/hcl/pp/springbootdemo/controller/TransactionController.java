package com.hcl.pp.springbootdemo.controller;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.pp.springbootdemo.controller.dto.TransactionDTO;
import com.hcl.pp.springbootdemo.dao.AccountDAO;
import com.hcl.pp.springbootdemo.exception.CustomerAccountNotFoundException;
import com.hcl.pp.springbootdemo.exception.CustomerInsufficientBalanceException;
import com.hcl.pp.springbootdemo.model.Account;
import com.hcl.pp.springbootdemo.model.Beneficiary;
import com.hcl.pp.springbootdemo.model.Transaction;
import com.hcl.pp.springbootdemo.service.TransactionService;

@RestController
public class TransactionController {

	private static final Logger logger = LoggerFactory.getLogger(TransactionController.class);

	
	@Autowired
	TransactionService transactionService;
	@Autowired
	AccountDAO accountDao;
	
	

	@RequestMapping("transaction/starttransaction")
	public String startTransaction(@RequestBody Transaction transaction,Account account) {
	    String str;
		str=(String) transactionService.startTransaction(transaction, account);
	    return str;
	}
	
	
	@RequestMapping("transaction/startDtotransaction")
	@ResponseBody public String startDtoTransaction(@RequestBody Transaction transaction,Account account) {
		ModelMapper modelMapper = new ModelMapper();
		
		Account account1 = accountDao.findById(transaction.getAccno()).orElse(null);
		if(account1 == null) {
			throw new CustomerAccountNotFoundException("Account number not found  " +transaction.getAccno());
		}
	
		
		TransactionDTO transactionDto = modelMapper.map(transaction,TransactionDTO.class);
		
		return transactionService.startDtoTransaction(transactionDto, account);
	    
	}

	
	
    @RequestMapping("transaction/balance")
    public String checkBalance(@RequestBody Account account) {
		
		logger.info("Displaying the balance");
     return transactionService.checkBalance(account);
    	
    
    }
    
    @RequestMapping("transaction/pagination")
    @GetMapping
    public ResponseEntity<List<TransactionDTO>> getAllTransaction(
                        @RequestParam(defaultValue = "0") Integer pageNo, 
                        @RequestParam(defaultValue = "10") Integer pageSize,
                        @RequestParam(defaultValue = "amt") String sortBy) 
    {
        List<TransactionDTO> list = transactionService.getAllTransaction(pageNo, pageSize, sortBy);
 
        return new ResponseEntity<List<TransactionDTO>>(list, new HttpHeaders(), HttpStatus.OK); 
    }

    
}

