package com.hcl.pp.springbootdemo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "customerdetails")
public class Customer {
	
	@Id
	Integer cust_id;
	String cust_name;
	int cust_age;
	String cust_phoneNo;
	String cust_email;
	String cust_job;
	String cust_acc;
	int cust_passwd;

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public int getCust_age() {
		return cust_age;
	}

	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}

	public String getCust_phoneNo() {
		return cust_phoneNo;
	}

	public void setCust_phoneNo(String cust_phoneNo) {
		this.cust_phoneNo = cust_phoneNo;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public String getCust_job() {
		return cust_job;
	}

	public void setCust_job(String cust_job) {
		this.cust_job = cust_job;
	}

	public String getCust_acc() {
		return cust_acc;
	}

	public void setCust_acc(String cust_acc) {
		this.cust_acc = cust_acc;
	}

	public int getCust_passwd() {
		return cust_passwd;
	}

	public void setCust_passwd(int cust_passwd) {
		this.cust_passwd = cust_passwd;
	}

	public Integer getCust_id() {
		return cust_id;
	}

	public void setCust_id(Integer cust_id) {
		this.cust_id = cust_id;
	}



}
