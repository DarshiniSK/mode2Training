package com.hcl.pp.springbootdemo.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.hcl.pp.springbootdemo.controller.dto.TransactionDTO;

public interface PaginationDAO extends PagingAndSortingRepository<TransactionDTO, String>{

}
