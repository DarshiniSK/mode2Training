package com.hcl.pp.springbootdemo.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.pp.springbootdemo.model.Beneficiary;

@Repository
public interface BeneficiaryDAO extends CrudRepository<Beneficiary,Integer> {

	
	  Optional<Beneficiary> findByIfsccodeAndBeneaccno(String ifsccode, String
	  beneaccno);
	 

	Optional<Beneficiary> findByIfsccode(String ifsccode);


}
