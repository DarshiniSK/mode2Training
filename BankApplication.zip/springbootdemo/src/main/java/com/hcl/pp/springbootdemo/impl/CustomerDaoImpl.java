package com.hcl.pp.springbootdemo.impl;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerDaoImpl{



}
