package com.hcl.pp.springbootdemo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.pp.springbootdemo.dao.CustomerDAO;
import com.hcl.pp.springbootdemo.model.Customer;
import com.hcl.pp.springbootdemo.service.CustomerService;

@Service
public class CustomerServiceImpl {


}
