package com.hcl.pp.springbootdemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.pp.springbootdemo.dao.CustomerDAO;
import com.hcl.pp.springbootdemo.model.Customer;

@Service
public class CustomerService {
	@Autowired
	CustomerDAO customerDao;

	public String addCustomerDetails(Customer customer) {
		if(customer.getCust_age()<18 && customer.getCust_phoneNo().length()<10) {
			return "not eligible to create bank account";
		}
		else {
			customerDao.save(customer);
			return "account created successfully";
		}

	}

	public Customer getAllCustomers(Customer customer) {
		return (Customer) customerDao.findAll();
		// TODO Auto-generated method stub

	}

	public void deleteCustomers(Customer customer) {
		// TODO Auto-generated method stub
		customerDao.deleteById(customer.getCust_id());
	}

	public void updateCustomers(Customer customer) {
		// TODO Auto-generated method stub
		Customer updatedetails=customerDao.findById(customer.getCust_id()).orElse(customer);
		updatedetails.setCust_age(customer.getCust_age());
		customerDao.save(updatedetails);
	}

	 
	

}
