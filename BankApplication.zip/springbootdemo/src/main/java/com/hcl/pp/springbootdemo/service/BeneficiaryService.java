package com.hcl.pp.springbootdemo.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.pp.springbootdemo.dao.BeneficiaryDAO;
import com.hcl.pp.springbootdemo.model.Beneficiary;

@Service
public class BeneficiaryService {
	
	@Autowired BeneficiaryDAO beneficiaryDao;
	
	//search the customer by ifsc code
	
	  public Optional<Beneficiary> findByIfsccode(String ifsccode) { // TODO	  
	  
	  return beneficiaryDao.findByIfsccode(ifsccode);
	  
	  }
	  
	 
	
	 //adding beneficiary
	
	public String addBeneficiaries(Beneficiary beneficiary) {
		// TODO Auto-generated method stub
		beneficiaryDao.save(beneficiary);
	 return "Beneficiary added successfully";
	}

	//search the customer by ifsc code and beneficiary account  number

	
	  public Optional<Beneficiary> findByIfsccodeAndBeneaccno(String ifsccode, String beneaccno) {
		return beneficiaryDao.findByIfsccodeAndBeneaccno(ifsccode,beneaccno); // TODO Auto-generated method stub return
 }
	 
}
