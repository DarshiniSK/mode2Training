package com.hcl.pp.springbootdemo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "beneficiaryDetails")
public class Beneficiary {

	@Id
	Integer cust_id;
	String beneaccno;
	String ifsccode;
	public Integer getCust_id() {  
		return cust_id;
	}
	public void setCust_id(Integer cust_id) {
		this.cust_id = cust_id;
	}
	public String getBeneaccno() {
		return beneaccno;
	}
	public void setBeneaccno(String beneaccno) {
		this.beneaccno = beneaccno;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	
	
}
