package com.hcl.pp.springbootdemo.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hcl.pp.springbootdemo.controller.dto.TransactionDTO;
import com.hcl.pp.springbootdemo.dao.AccountDAO;
import com.hcl.pp.springbootdemo.dao.PaginationDAO;
import com.hcl.pp.springbootdemo.dao.TransactionDAO;
import com.hcl.pp.springbootdemo.exception.CustomerInsufficientBalanceException;
import com.hcl.pp.springbootdemo.model.Account;
import com.hcl.pp.springbootdemo.model.Transaction;

@Service
public class TransactionService {

	@Autowired
	TransactionDAO transactionDao;
	@Autowired 
	PaginationDAO paginationDao;
	@Autowired
	AccountDAO accountDao;
	String message;
	int frombal, tobal;

	public String startTransaction(Transaction transaction, Account account) {
		// TODO Auto-generated method stub

		/*
		 * transactionDao.save(transaction);
		 * System.out.println("Transaction details are saved"); Transaction
		 * translist=transactionDao.findById(transaction.getFrom_accno()).orElse(null);
		 * Account acclist1=accountDao.findById(translist.getFrom_accno()).orElse(null);
		 * Account
		 * acclist2=accountDao.findById(translist.getTo_accno()).orElse(account);
		 * 
		 * if(translist.getAmt()<acclist1.getBalance()) { int frombal =
		 * acclist1.getBalance(); int tobal = acclist2.getBalance();
		 * 
		 * frombal=frombal-translist.getAmt(); tobal=tobal+translist.getAmt();
		 * 
		 * acclist1.setBalance(frombal); acclist2.setBalance(tobal);
		 * 
		 * accountDao.save(acclist1); accountDao.save(acclist2);
		 * 
		 * System.out.println("to account number is: "+translist.getTo_accno());
		 * 
		 * transaction.setFrom_accno(translist.getTo_accno());
		 * transaction.setAmt(translist.getAmt());
		 * transaction.setDescription("receiving amount");
		 * transaction.setTo_accno(null); transaction.setTransaction_type("credited");
		 * transactionDao.save(transaction);
		 * 
		 * message = "transaction completed successfully";
		 * 
		 * } else { message="Insufficient balance in the account"; } return message;
		 * 
		 */		return message;
	}

	public String checkBalance(Account account) {

		Account accbal = accountDao.findById(account.getAccno()).orElse(null);
		String message2 = "account balance is: ";
		int bal;
		bal = accbal.getBalance();
		message2 = message2 + bal;
		return message2;
		// TODO Auto-generated method stub

	}

	public String startDtoTransaction(TransactionDTO transactionDto, Account account) {

		// changes have to be made here
		TransactionDTO translist2 = transactionDao.findById(transactionDto.getAccno()).orElse(transactionDto);
		System.out.println("User sent accnumber is=" + translist2.getAccno());
		System.out.println("Saving on the database");
		transactionDao.save(transactionDto);
		transactionDto.setAccno("SBI123457");
		transactionDto.setAmt(transactionDto.getAmt());
		transactionDto.setTransaction_type("Debitting");
		transactionDto.setDescription("Debitting");
		transactionDao.save(transactionDto);

		System.out.println("Transaction details successfully saved!!");

		// From address details
		TransactionDTO translist = transactionDao.findById("SBI123457").orElse(null);
		Account acclist2 = accountDao.findById(translist.getAccno()).orElse(account);

		// To address details
		Account acclist1 = accountDao.findById(translist2.getAccno()).orElse(null);

		System.out.println(translist2.getAmt() + "<" + acclist2.getBalance());

		if (translist2.getAmt() < acclist2.getBalance()) {
			frombal = acclist2.getBalance();
			tobal = acclist1.getBalance();

			frombal = frombal - translist2.getAmt();
			tobal = tobal + translist2.getAmt();

			acclist1.setBalance(tobal);
			acclist2.setBalance(frombal);

			accountDao.save(acclist1);
			accountDao.save(acclist2);
			
			System.out.println("To acc number is=" + translist2.getAccno());
			
			transactionDto.setAccno(translist2.getAccno());
			transactionDto.setAmt(translist.getAmt());
			transactionDto.setDescription("Recieving Amount");
			transactionDto.setTransaction_type("Credited");
			transactionDao.save(transactionDto);

			message = "Transaction completed successfully";
		} else {
			throw new CustomerInsufficientBalanceException("Insufficient account balance.... available balance is: "+acclist2.getBalance());

		}
		return message;
	}
	
	public List<TransactionDTO> getAllTransaction(Integer pageNo, Integer pageSize, String sortBy)
    {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
 
        Page<TransactionDTO> pagedResult = paginationDao.findAll(paging);
         
        if(pagedResult.hasContent()) {
            return pagedResult.getContent();
        } else {
            return new ArrayList<TransactionDTO>();
        }
    }

}

