package com.hcl.pp.springbootdemo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.pp.springbootdemo.dao.CustomerDAO;
import com.hcl.pp.springbootdemo.model.Customer;
import com.hcl.pp.springbootdemo.service.CustomerService;

@RestController

public class CustomerController {

	@Autowired
	CustomerService custservice;

	/* @RequestMapping(value = "customer/add", method = RequestMethod.POST) */
	@PostMapping("customer/add")
	public String addCustomerDetails(@RequestBody Customer customer) {
	    String str;
		str=custservice.addCustomerDetails(customer);
	return str;
	}
	
	@Autowired CustomerDAO customerDao;
    @RequestMapping("customer/getall")
    @ResponseBody public  Iterable<Customer> getAllCustomers() {
    	return customerDao.findAll();
    }

    @RequestMapping("customer/getdetails")
    @ResponseBody public   Optional<Customer> getCustomerDetails(@RequestBody Customer customer) {
    return customerDao.findById(customer.getCust_id());
    }
    
	@PostMapping("customer/delete")
	public void deleteCustomers(@RequestBody Customer customer) {
		custservice.deleteCustomers(customer);
	}

	@PostMapping("customer/update")
	public String updateCustomers(@RequestBody Customer customer) {
		custservice.updateCustomers(customer);
		return "Updated Successfully";
	}

}
