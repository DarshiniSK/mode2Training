package com.hcl.pp.springbootdemo.impl;

import org.springframework.stereotype.Service;

@Service
public class BeneficiaryDAOImpl {

}
