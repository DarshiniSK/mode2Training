package com.example.demo.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shows")
public class Shows {

	@Id
	Integer showid;
	Integer theatreid;
	LocalDate date;
	String morningshow;
	String noonshow;
	String eveningshow;
	
	public Integer getShowid() {
		return showid;
	}
	public Integer getTheatreid() {
		return theatreid;
	}
	public void setTheatreid(Integer theatreid) {
		this.theatreid = theatreid;
	}
	public void setShowid(Integer showid) {
		this.showid = showid;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getMorningshow() {
		return morningshow;
	}
	public void setMorningshow(String morningshow) {
		this.morningshow = morningshow;
	}
	public String getNoonshow() {
		return noonshow;
	}
	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}
	public String getEveningshow() {
		return eveningshow;
	}
	public void setEveningshow(String eveningshow) {
		this.eveningshow = eveningshow;
	}
	
	}

