package com.example.demo.impl;

import org.springframework.stereotype.Service;

@Service
public class BookingServiceImpl {

}
