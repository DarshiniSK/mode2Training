package com.example.demo.dto;

public class TheatreShowDTO {

	String theatrename;
	String place;
	String morningshow;
	public String getMorningshow() {
		return morningshow;
	}
	public void setMorningshow(String morningshow) {
		this.morningshow = morningshow;
	}
	String noonshow;
	String eveningshow;
	public String getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getNoonshow() {
		return noonshow;
	}
	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}
	public String getEveningshow() {
		return eveningshow;
	}
	public void setEveningshow(String eveningshow) {
		this.eveningshow = eveningshow;
	}
	
}
