package com.example.demo.controller;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.TheatreShowDTO;
import com.example.demo.model.Booking;
import com.example.demo.model.Movie;
import com.example.demo.model.Shows;
import com.example.demo.model.Theatre;
import com.example.demo.service.BookingService;

@RestController
public class BookingController {

	@Autowired
	BookingService bookingService;

	@RequestMapping(value = "add/theatre")
	@ResponseBody
	public String addTheatreDetails(@RequestBody Theatre theatre) {
		return bookingService.addTheatreDetails(theatre);
	}

	@RequestMapping(value = "add/movie")
	@ResponseBody
	public String addMovieDetails(@RequestBody Movie movie) {

		return bookingService.addMovieDetails(movie);
	}

	@RequestMapping(value = "add/show")
	@ResponseBody
	public String addShowsDetails(@RequestBody Shows shows) {
		return bookingService.addShowsDetails(shows);
	}

	@RequestMapping(value = "add/booking")
	@ResponseBody
	public String addBookingDetails(@RequestBody Booking booking) {
		return bookingService.addBookingDetails(booking);
	}

	@RequestMapping(value = "add/getalltheatre/{moviename}")
	@ResponseBody
	public List<TheatreShowDTO> getTheatreDetails(@PathVariable(value = "moviename") String moviename) {
		return bookingService.getTheatreDetails(moviename);
	}

	@RequestMapping(value = "add/{moviename}/{theatrename}/{showtime}")
	@ResponseBody
	public String BookMovieTicket(@PathVariable(value = "moviename") String moviename,
			@PathVariable(value = "theatrename") String theatrename,
			@PathVariable(value = "showtime") String showtime) {
	return bookingService.BookMovieTicket(moviename, theatrename, showtime);
	}

	/*
	 * @RequestMapping(value="add/ticket")
	 * 
	 * @ResponseBody public Booking BookMovieTicket(@RequestParam String
	 * moviename,@RequestParam Integer theatreid,@RequestParam LocalTime
	 * showtime,@RequestParam Integer userid) { return (Booking)
	 * bookingService.BookMovieTicket(moviename,theatreid,showtime,userid); }
	 */
}
