package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Booking;
import com.example.demo.model.Shows;

@Repository
public interface BookingDAO extends CrudRepository<Booking,Integer>{

}
