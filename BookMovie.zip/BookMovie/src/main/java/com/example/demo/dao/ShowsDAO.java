package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Shows;
import com.example.demo.model.Theatre;

@Repository
public interface ShowsDAO extends CrudRepository<Shows,Integer>  {

	@Query(value="select * from shows s where s.morningshow=?1 or s.noonshow=?1 or s.eveningshow=?1", nativeQuery= true)
	List<Shows> getTheatreDetails(String moviename);
}
