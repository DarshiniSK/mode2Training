package com.example.demo.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BookingDAO;
import com.example.demo.dao.MovieDAO;
import com.example.demo.dao.ShowsDAO;
import com.example.demo.dao.TheatreDAO;
import com.example.demo.dto.TheatreShowDTO;
import com.example.demo.model.Booking;
import com.example.demo.model.Movie;
import com.example.demo.model.Shows;
import com.example.demo.model.Theatre;

@Service
public class BookingService {

	@Autowired
	TheatreDAO theatreDao;
	@Autowired
	ShowsDAO showsDao;
	@Autowired
	MovieDAO movieDao;
	@Autowired
	BookingDAO bookingDao;

	
	//adding theater details
	
	public String addTheatreDetails(Theatre theatre) {
		// TODO Auto-generated method stub
		theatreDao.save(theatre);
		return "theatre data saved successfully";
	}

	//adding movie details

	public String addMovieDetails(Movie movie) {
		// TODO Auto-generated method stub
		movieDao.save(movie);
		return "movie details saved successfully";
	}

	//adding shows details

	public String addShowsDetails(Shows shows) {
		// TODO Auto-generated method stub
		showsDao.save(shows);
		return "show details saved successfully";
	}

	//adding booking details

	public String addBookingDetails(Booking booking) {
		// TODO Auto-generated method stub
		bookingDao.save(booking);
		return "ticket booked successfully";
	}

	//listing theater details

	public List<TheatreShowDTO> getTheatreDetails(String moviename) {
		// TODO Auto-generated method stub
		List<Shows> showlist = showsDao.getTheatreDetails(moviename);
		Theatre th1 = new Theatre();
		List<TheatreShowDTO> list = new ArrayList();
		for (Shows show : showlist) {

			TheatreShowDTO th2 = new TheatreShowDTO();
			Integer theatreid = show.getTheatreid();
			th1 = theatreDao.findById(theatreid).orElse(null);
			th2.setPlace(th1.getPlace());
			th2.setTheatrename(th1.getTheatrename());
			th2.setMorningshow(show.getMorningshow());
			th2.setNoonshow(show.getNoonshow());
			th2.setEveningshow(show.getEveningshow());
			list.add(th2);
		}
		return list;
	}



//booking movie details
	public String BookMovieTicket(String moviename, String theatrename, String showtime) {
		// TODO Auto-generated method stub
		Booking book=new Booking();
		int id1=124;
		int id2=202;
        book.setBookingid(id1++);
		book.setDate(LocalDate.now());
		book.setMoviename(moviename);
		book.setShowtime(showtime);
		book.setTheatrename(theatrename);
		book.setUserid(id2++);
	 bookingDao.save(book);

		return "ticket book successfully";
	}

}
