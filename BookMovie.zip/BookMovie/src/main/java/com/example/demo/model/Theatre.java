package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "theatre")
public class Theatre {

	@Id
	Integer theatreid;
	String theatrename;
	String place;
	
	public Integer getTheatreid() {
		return theatreid;
	}
	public void setTheatreid(Integer theatreid) {
		this.theatreid = theatreid;
	}
	public String getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	
}
