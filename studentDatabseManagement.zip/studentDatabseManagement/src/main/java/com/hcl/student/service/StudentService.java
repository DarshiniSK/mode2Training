package com.hcl.student.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hcl.student.model.Academic;
import com.hcl.student.model.Student;

@Service
public interface StudentService {
	
	public void registerStudent(Student student, Academic academic);

	public String searchStudent(Student student);


}
