package com.hcl.student.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcl.student.dao.StudentDAO;
import com.hcl.student.model.Academic;
import com.hcl.student.model.Student;
import com.hcl.student.service.StudentService;

public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentDAO studentdao;
	
	
	@Override
	public void registerStudent(Student student,Academic academic) {
		// TODO Auto-generated method stub
		studentdao.registerStudent(student,academic);
	}
	@Override
	public String searchStudent(Student student) {
		// TODO Auto-generated method stub
		return studentdao.searchStudent(student);
	}
	
	

}
