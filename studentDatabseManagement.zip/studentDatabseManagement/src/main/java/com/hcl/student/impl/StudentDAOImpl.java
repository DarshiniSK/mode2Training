package com.hcl.student.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.tree.RowMapper;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.student.dao.StudentDAO;
import com.hcl.student.model.Academic;
import com.hcl.student.model.College;
import com.hcl.student.model.Student;

public class StudentDAOImpl implements StudentDAO {

	@Autowired
	SessionFactory sessionFactory;

	//registering the student
	
	@Transactional
	@Override
	public void registerStudent(Student student,Academic academic) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(student);
		sessionFactory.getCurrentSession().save(academic);
	}

	//search a student using usn
	
	@Override
	public String searchStudent(Student student) {
		// TODO Auto-generated method stub
		String usnCollegeCode;
		String temp;
		String place = null;
		temp = student.getUsn();
		StringBuffer sb = new StringBuffer(temp);
		String temp1 = sb.substring(1, 3);

		System.out.println(temp1);

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		String sql_query = "from College where collegecode = '" + temp1 + "'";
		Query query = session.createQuery(sql_query);
		List list = query.list();
		System.out.println("Display the content of list");
		Iterator it = list.iterator();
		while (it.hasNext()) {
			Object obj = (Object) it.next();
			College studlist = (College) obj;
			System.out.println(studlist.getPlace());
			place = studlist.getPlace();

		}

		session.close();

		return "The student is from: " + place;
	}
	
	
	//list all the students in the database with pagination

	public static List<Student> getStudentsByPage(int pageid, int total) {
		// TODO Auto-generated method stub

		Object obj = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		String sql = "from Student";
		Query query = session.createQuery(sql);
		query.setFirstResult(pageid-1);
		query.setMaxResults(total);
		 List<Student> stddet=new ArrayList<Student>();
		List studlist = query.list();
		System.out.println("Displaying pagination contents");
		  Iterator it = studlist.iterator();
		  Student std = new Student();
	      while(it.hasNext())
	      {
	         std = (Student) it.next();
	        System.out.println(std.getUsn() + "  " + std.getName() + "  " + std.getFather()+ " " + std.getMother());
	        stddet.add(std);
	      }
		return stddet;
		

	}
	
	//using criteria query
	
	public static List<Student> getAllStudents() {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Criteria cr=session.createCriteria(Student.class);
		cr.add(Restrictions.gt("age", "21"));
		
		List<Student> stddet=new ArrayList<Student>();
		List studlist = cr.list();
		System.out.println("Displaying pagination contents");
		  Iterator it = studlist.iterator();
		  Student std = new Student();
	      while(it.hasNext())
	      {
	         std = (Student) it.next();
	        System.out.println(std.getUsn() + "  " + std.getName() + "  " + std.getFather()+ " " + std.getMother());
	        stddet.add(std);
	      }
		return stddet;
		

	
	}
}
