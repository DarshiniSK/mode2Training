package com.hcl.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(CourseKey.class)
@Table(name="course")
public class Course {

	@Id
	String collegecode;
	@Id
	String coursename;
	
}
