package com.hcl.student.model;

import java.io.Serializable;

public class CourseKey implements Serializable {

	String collegecode;
	String coursename;
	
}
