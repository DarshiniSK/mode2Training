package com.hcl.student.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.hcl.student.model.Academic;
import com.hcl.student.model.Student;

@Repository
public interface StudentDAO {

	public void registerStudent(Student student, Academic academic);

	public String searchStudent(Student student);

	
}
