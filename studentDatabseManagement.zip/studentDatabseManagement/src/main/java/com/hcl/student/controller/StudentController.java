package com.hcl.student.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcl.student.dto.StudentDetailsDTO;
import com.hcl.student.impl.StudentDAOImpl;
import com.hcl.student.model.Academic;
import com.hcl.student.model.Student;
import com.hcl.student.service.StudentService;


@Controller
public class StudentController {
	
	@Autowired
	StudentService studentservice;
	
	
	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
	
	@RequestMapping(value= "/stud/add", method = RequestMethod.GET)
	public String addStudentDetails(@ModelAttribute("studentDetailsDTO")StudentDetailsDTO studentDetailsDTO,BindingResult bindingResult, Model model)
	{
		logger.info("Returning userregn.jsp page");
		model.addAttribute("studentDetailsDTO", new StudentDetailsDTO());
		return "student-register";
	}
	
	
	@RequestMapping(value= "/stud/add.do", method = RequestMethod.POST)
	public String addStudent(@ModelAttribute("studentDetailsDTO") StudentDetailsDTO studentDetailsDTO ,BindingResult bindingResult, Model model){
		if (bindingResult.hasErrors()) {
			logger.info("Returning error-register.jsp page");
			return "error";
		}
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studentDetailsDTO, Student.class);
		Academic academic = mapper.map(studentDetailsDTO, Academic.class);
		model.addAttribute("studentDetailsDTO", studentDetailsDTO);
		studentservice.registerStudent(student,academic);
		logger.info("Returning success-registered page");
		return "success-registered";
	}
	
	@RequestMapping(value= "/stud/search", method = RequestMethod.GET)
	public String searchStudent(@ModelAttribute("student") Student student,BindingResult bindingResult, Model model)
	{
		logger.info("Returning searchstudent.jsp page");
		model.addAttribute("student", new Student());
		return "student-search";
	}
	
	
	@RequestMapping(value= "/stud/search.do", method = RequestMethod.POST)
	@ResponseBody
	public String searchStudentPlace(@ModelAttribute("student") Student student,BindingResult bindingResult, Model model)
	{
		logger.info("Returning searchstudent page");
		model.addAttribute("student", student);
		return studentservice.searchStudent(student);
		
	}
	
	
	
	@RequestMapping(value= "/stud/studentdetails", method = RequestMethod.GET)
	public String getStudentDetails(@ModelAttribute("studentDetailsDTO") StudentDetailsDTO studentDetailsDTO,BindingResult bindingResult, Model model)
	{
		logger.info("Returning index.jsp page");
		return "index";
		
	}
	
	
	@RequestMapping(value="/viewstud/{pageid}") 
	public String getAllStudentDetails(@PathVariable int pageid,Model model)
	{
		int total=5;    
        if(pageid==1){}    
        else{    
            pageid=(pageid-1)*total+1;    
        }    
        System.out.println(pageid);  
        List<Student> list=StudentDAOImpl.getStudentsByPage(pageid,total);    
          model.addAttribute("msg", list);  
          return "student-list";  
	}
	
	@RequestMapping(value="/get")
	@ResponseBody
	public String fromPostman(@RequestBody Student student) {
		return studentservice.searchStudent(student);
	}

	@RequestMapping(value="/getall")
	@ResponseBody
	public List<Student> getAllStudents()
{
return StudentDAOImpl.getAllStudents();
	}



}
